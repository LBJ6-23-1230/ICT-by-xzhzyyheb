# -*- coding: utf-8 -*-
"""平台事件 → 网关内部事件。

为什么不在前端直接消费平台事件
------------------------------
平台事件是"给开发者看的"（`plugin_start` / `summary_response`），而前端要的是
"给用户看的"（工具开始、工具完成、指标、最终消息）。中间这层归一化还能吃掉两类差异：

1. 平台可能新增事件类型 —— 未知事件统一包成 `raw` 透传，**不丢弃**，否则调试时
   会发现"平台明明调了工具，前端什么都没有"。
2. 多智能体场景可能追加节点/转交事件 —— 同样落进 `raw`，等确认字段后再提升为正式事件。
"""

from __future__ import annotations

#: 内部事件类型。前端与评测脚本只依赖这一组，不依赖平台命名。
RUN_STARTED = "run_started"
AGENT_MESSAGE = "agent_message"
TOOL_STARTED = "tool_started"
TOOL_FINISHED = "tool_finished"
METRICS = "metrics"
RUN_SUMMARY = "run_summary"
RUN_FINISHED = "run_finished"
RAW = "raw"


def normalize(event: dict) -> dict:
    """单个平台事件 → 内部事件。纯函数，不抛异常（坏数据退化为 raw）。"""
    if not isinstance(event, dict):
        return {"type": RAW, "rawEvent": str(event)[:200]}

    name = str(event.get("event") or "")
    created = event.get("createdTime")

    if name == "start":
        return {"type": RUN_STARTED, "createdTime": created}

    if name == "message":
        return {"type": AGENT_MESSAGE, "delta": str(event.get("content") or ""),
                "createdTime": created}

    if name == "plugin_start":
        plugin = event.get("plugin") if isinstance(event.get("plugin"), dict) else {}
        return {
            "type": TOOL_STARTED,
            "name": str(plugin.get("name") or ""),
            "arguments": plugin.get("arguments") if isinstance(plugin.get("arguments"), dict) else {},
            "createdTime": created,
        }

    if name == "plugin_end":
        plugin = event.get("plugin") if isinstance(event.get("plugin"), dict) else {}
        latency = event.get("latency") if isinstance(event.get("latency"), dict) else {}
        return {
            "type": TOOL_FINISHED,
            "name": str(plugin.get("name") or ""),
            "ok": bool(event.get("success", True)),
            "latencyMs": latency.get("plugin"),
            "createdTime": created,
        }

    if name == "statistic_data":
        latency = event.get("latency") if isinstance(event.get("latency"), dict) else {}
        return {
            "type": METRICS,
            "latency": {key: latency.get(key) for key in ("plugin", "model", "overall")},
            "createdTime": created,
        }

    if name == "summary_response":
        return {"type": RUN_SUMMARY, "text": str(event.get("content") or ""),
                "role": str(event.get("role") or "assistant"), "createdTime": created}

    if name == "done":
        return {"type": RUN_FINISHED, "createdTime": created}

    return {"type": RAW, "platformEvent": name or "unknown", "rawEvent": event}


def collect_text(events) -> str:
    """从已归一化的事件里拼出完整回复（用于落库与评测比对）。"""
    return "".join(item.get("delta") or "" for item in events if item.get("type") == AGENT_MESSAGE)


def tool_names(events) -> list[str]:
    """按出现顺序去重收集工具名，评测脚本用它断言"该调的工具调了没有"。"""
    seen: list[str] = []
    for item in events:
        if item.get("type") == TOOL_STARTED:
            name = str(item.get("name") or "")
            if name and name not in seen:
                seen.append(name)
    return seen
