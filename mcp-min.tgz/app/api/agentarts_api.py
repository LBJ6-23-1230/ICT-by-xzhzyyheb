# -*- coding: utf-8 -*-
"""`/api/v2/agent/*` —— AgentArts 网关。

这一层存在的唯一理由：**云凭据不能下发客户端**。
App / Web 只认业务会话令牌（`Authorization: Bearer`），IAM 密码与 Token 全部留在服务端。

四个端点
--------
* `POST /chat`     主链路，SSE 流式。先取 Token 再开流，保证"连不上"是一句干净的错误，
                   而不是流到一半断掉。
* `GET  /runs/<id>` 事件回放。SSE 只在连接存活期有效；页面刷新、App 轮询失败后靠它恢复
                   时间线，评测脚本也靠它离线分析。
* `GET  /runtime`   配置与 Token 缓存状态（**不含任何密钥**），Demo 用它显示"云端/降级"徽标。
* `POST /feedback`  把"有用/无用"沉淀成评测样本——评测集不该靠事后编造。

降级口径
--------
未配置 / 未开启 / 平台不可达，一律返回明确错误码 + `fallback: false`。
**绝不**在云端失败时偷偷返回本地结果还标成云端。
"""

from __future__ import annotations

import json
from datetime import datetime, timezone

from flask import Blueprint, Response, jsonify, request, stream_with_context

from app.agentarts import (
    AgentArtsClient,
    AgentArtsConfig,
    AgentArtsError,
    IamTokenProvider,
    MODE_CLOUD,
    normalize,
)
from app.agentarts import session as store
from app.api.identity import can_read_user, current_user_id, resolve_user_id

agentarts_api = Blueprint("agentarts", __name__)

_repository = None
_config: AgentArtsConfig | None = None
_client: AgentArtsClient | None = None
_tokens: IamTokenProvider | None = None

MAX_MESSAGE_CHARS = 4000


def configure_agentarts(repository, *, config: AgentArtsConfig | None = None,
                        client: AgentArtsClient | None = None,
                        tokens: IamTokenProvider | None = None) -> None:
    """由 `create_app()` 调用；测试里可注入假 config / client 完全离线。"""
    global _repository, _config, _client, _tokens
    _repository = repository
    _config = config or AgentArtsConfig.from_env()
    _tokens = tokens or IamTokenProvider(_config)
    _client = client or AgentArtsClient(_config, _tokens)


def _cfg() -> AgentArtsConfig:
    global _config
    if _config is None:
        _config = AgentArtsConfig.from_env()
    return _config


def _cli() -> AgentArtsClient:
    global _client, _tokens
    if _client is None:
        _tokens = _tokens or IamTokenProvider(_cfg())
        _client = AgentArtsClient(_cfg(), _tokens)
    return _client


# ------------------------------------------------------------------ 工具
def _payload() -> dict:
    """宽松解析请求体：兼容带 charset 的 Content-Type（与聊天层同一处理）。"""
    data = request.get_json(silent=True)
    if isinstance(data, dict):
        return data
    raw = request.get_data() or b""
    if not raw.strip():
        return {}
    try:
        parsed = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, ValueError):
        return {}
    return parsed if isinstance(parsed, dict) else {}


def _error(status: int, code: str, message: str, *, details: dict | None = None,
           fallback: bool = False):
    body = {
        "errorCode": code,
        "message": message,
        "details": details or {},
        "fallback": fallback,
    }
    return jsonify(body), status


def _sse(event: dict, index: int) -> str:
    payload = json.dumps(event, ensure_ascii=False)
    return "id: %d\nevent: %s\ndata: %s\n\n" % (index, event.get("type", "message"), payload)


# ------------------------------------------------------------------ 主链路
@agentarts_api.post("/api/v2/agent/chat")
def agent_chat():
    config = _cfg()
    if config.mode != MODE_CLOUD:
        # 未开启或强制本地：这是配置状态，不是故障，但仍要明确告诉调用方。
        return _error(503, "AGENTARTS_DISABLED", config.blocking_reason(),
                      details={"mode": config.mode, "missing": config.missing()})

    data = _payload()
    message = str(data.get("message") or data.get("query") or "").strip()
    if not message:
        return _error(400, "BAD_REQUEST", "message 不能为空")
    if len(message) > MAX_MESSAGE_CHARS:
        return _error(400, "BAD_REQUEST", "message 超过 %d 字" % MAX_MESSAGE_CHARS)

    missing = config.missing()
    if missing:
        return _error(503, "AGENTARTS_CONFIG_INCOMPLETE",
                      "AgentArts 配置不完整：%s" % "、".join(missing),
                      details={"missing": missing})

    user_id = resolve_user_id(data.get("userId"))
    chat_session_id = str(data.get("sessionId") or "").strip()[:128] or ("chat-" + store.new_run_id())
    session = store.bind_session(_repository, user_id=user_id, chat_session_id=chat_session_id,
                                 agent_id=config.agent_id)

    client = _cli()
    try:
        client.ensure_ready()
    except AgentArtsError as error:
        # 连不上就不开流：502 + fallback:false，前端据此显示"云端不可用"，而不是空转。
        return _error(502, "AGENTARTS_UNAVAILABLE", str(error),
                      details={"status": error.status, "hint": error.hint}, fallback=False)

    run = store.start_run(_repository, conversation_id=session["conversationId"], user_id=user_id,
                          chat_session_id=chat_session_id, agent_id=config.agent_id)
    run_id = run["runId"]

    stream = client.run_agent(
        session["conversationId"], message, {"sessionRef": session["sessionRef"]})

    def generate():
        index = 0
        collected: list[dict] = []
        reply_parts: list[str] = []
        tools: list[str] = []
        finished = False

        yield _sse({
            "type": "ready",
            "runId": run_id,
            "conversationId": session["conversationId"],
            "agentId": config.agent_id,
            "agentVersion": config.agent_version,
            "mode": config.mode,
            "createdAt": datetime.now(timezone.utc).isoformat(),
        }, index)
        index += 1

        try:
            for platform_event in stream:
                event = normalize(platform_event)
                collected.append(event)
                if event.get("type") == "agent_message":
                    reply_parts.append(event.get("delta") or "")
                if event.get("type") == "tool_started" and event.get("name") not in tools:
                    tools.append(event["name"])
                if event.get("type") == "run_finished":
                    finished = True
                yield _sse(event, index)
                index += 1
        except AgentArtsError as error:
            collected.append({"type": "run_failed", "errorCode": "AGENTARTS_STREAM_ERROR",
                              "message": str(error), "hint": error.hint})
            # 断流前已经收到的事件必须一起落库：否则回放只剩一条 run_failed，
            # "失败前它其实说到哪一步了"这个最有价值的调试信息就丢了。
            store.append_events(_repository, run_id, collected)
            store.finish_run(_repository, run_id, status="failed", reply="".join(reply_parts),
                             tools=tools, error=str(error))
            yield _sse(collected[-1], index)
            return

        if not finished:
            # 平台提前断流（例如网关超时）。显式补一个结束事件，避免前端一直转圈。
            tail = {"type": "run_finished", "incomplete": True}
            collected.append(tail)
            yield _sse(tail, index)
            index += 1

        store.append_events(_repository, run_id, collected)
        store.finish_run(_repository, run_id, status="completed", reply="".join(reply_parts),
                         tools=tools)
        store.touch_session(_repository, session["conversationId"])

    return Response(
        stream_with_context(generate()),
        mimetype="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "X-Accel-Buffering": "no",
            "Connection": "keep-alive",
        },
    )


# ------------------------------------------------------------------ 回放
@agentarts_api.get("/api/v2/agent/runs/<run_id>")
def get_run(run_id: str):
    run = store.get_run(_repository, run_id)
    if not isinstance(run, dict):
        return _error(404, "NOT_FOUND", "run 不存在", details={"runId": run_id})
    # 与 /api/v1/traces 一致：不属于当前身份的运行一律 404，不泄漏存在性。
    if not can_read_user(str(run.get("userId") or "")):
        return _error(404, "NOT_FOUND", "run 不存在", details={"runId": run_id})

    try:
        after = max(0, int(request.args.get("after") or 0))
    except ValueError:
        after = 0

    events = store.events_since(_repository, run_id, after)
    return jsonify({
        "runId": run_id,
        "conversationId": run.get("conversationId"),
        "status": run.get("status"),
        "startedAt": run.get("startedAt"),
        "finishedAt": run.get("finishedAt"),
        "reply": run.get("reply"),
        "tools": run.get("tools") or [],
        "truncated": bool(run.get("truncated")),
        "total": len(run.get("events") or []),
        "after": after,
        "events": events,
    })


# ------------------------------------------------------------------ 状态
@agentarts_api.get("/api/v2/agent/runtime")
def runtime_status():
    config = _cfg()
    payload = config.describe()
    payload["auth"] = _tokens.snapshot() if _tokens is not None else {"cached": False}
    payload["contractNote"] = "v2 端点暂不校验 X-API-Contract-Version，契约升到 v0.4 后统一"
    return jsonify(payload)


# ------------------------------------------------------------------ 反馈
@agentarts_api.post("/api/v2/agent/feedback")
def submit_feedback():
    data = _payload()
    rating = str(data.get("rating") or "").strip()
    if rating not in ("helpful", "unhelpful"):
        return _error(400, "BAD_REQUEST", "rating 只能是 helpful / unhelpful")

    run_id = str(data.get("runId") or "").strip()
    run = store.get_run(_repository, run_id) if run_id else None
    if not isinstance(run, dict):
        return _error(404, "NOT_FOUND", "run 不存在", details={"runId": run_id})

    user_id = current_user_id() or resolve_user_id(data.get("userId"))
    if not can_read_user(str(run.get("userId") or "")):
        return _error(404, "NOT_FOUND", "run 不存在", details={"runId": run_id})

    record = store.save_feedback(_repository, run_id=run_id, user_id=user_id, rating=rating,
                                note=str(data.get("note") or ""))
    return jsonify({"status": "ok", "feedbackId": record["feedbackId"]}), 201
