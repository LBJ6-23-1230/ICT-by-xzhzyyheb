# -*- coding: utf-8 -*-
"""工具注册表：声明式定义 + 统一校验 + 统一分发。

一条纪律：**注册表里只描述"怎么调已有的函数"，不实现业务规则。**
优先级、预算裁剪、判分、掌握度、重排的算法都在 `app/decision` 与 `app/tools` 里，
那些代码有测试覆盖；这里复制一份就等于制造第二份真源，两边迟早算得不一样。
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any, Callable

from . import envelope

logger = logging.getLogger("zhixue.mcp")

#: 类型名 → 校验函数。只做粗校验：MCP 的 inputSchema 由平台侧保证结构，
#: 这里防的是"模型把字符串塞进整数位"这类明显错误。
_TYPES = {
    "string": str,
    "integer": int,
    "number": (int, float),
    "boolean": bool,
    "array": list,
    "object": dict,
}


@dataclass
class ToolContext:
    repository: Any
    user_id: str
    session_ref: str = ""
    conversation_id: str = ""
    idempotency_key: str = ""


@dataclass
class ToolSpec:
    name: str
    title: str
    description: str
    properties: dict[str, dict]
    handler: Callable[[dict, ToolContext], dict]
    required: list[str] = field(default_factory=lambda: ["sessionRef"])
    write: bool = False

    @property
    def input_schema(self) -> dict:
        return {
            "type": "object",
            "properties": self.properties,
            "required": list(self.required),
            "additionalProperties": False,
        }

    def validate(self, arguments: dict) -> str:
        for key in self.required:
            value = arguments.get(key)
            if value is None or (isinstance(value, str) and not value.strip()):
                return "缺少必填参数：%s" % key
        for key, spec in self.properties.items():
            if key not in arguments:
                continue
            value = arguments[key]
            expected = spec.get("type")
            python_type = _TYPES.get(expected)
            if python_type is None:
                continue
            # bool 是 int 的子类，单独挡一下，避免 true 被当成 1。
            if expected in ("integer", "number") and isinstance(value, bool):
                return "参数 %s 类型应为 %s" % (key, expected)
            if not isinstance(value, python_type):
                return "参数 %s 类型应为 %s" % (key, expected)
        return ""

    def describe(self) -> dict:
        return {
            "name": self.name,
            "title": self.title,
            "description": self.description,
            "inputSchema": self.input_schema,
        }


class ToolRegistry:
    def __init__(self, tools: list[ToolSpec]) -> None:
        self._tools = {tool.name: tool for tool in tools}
        if len(self._tools) != len(tools):
            raise ValueError("工具名重复")

    # ------------------------------------------------------------ 查询
    def names(self) -> list[str]:
        return list(self._tools)

    def get(self, name: str) -> ToolSpec | None:
        return self._tools.get(name)

    def describe(self) -> list[dict]:
        return [tool.describe() for tool in self._tools.values()]

    def writes(self) -> list[str]:
        return [tool.name for tool in self._tools.values() if tool.write]

    # ------------------------------------------------------------ 调用
    def call(self, name: str, arguments: dict, context: ToolContext) -> dict:
        tool = self._tools.get(name)
        if tool is None:
            return envelope.fail(envelope.NOT_FOUND, "未知工具：%s" % name,
                                 details={"available": list(self._tools)})

        # 越权防线（第一层）：模型不能自己声称身份。
        if "userId" in arguments:
            return envelope.fail(
                envelope.VALIDATION_ERROR,
                "工具入参不允许 userId；身份只能由 sessionRef 推导",
                details={"parameter": "userId"})

        problem = tool.validate(arguments)
        if problem:
            return envelope.fail(envelope.VALIDATION_ERROR, problem,
                                 details={"tool": name})

        try:
            return tool.handler(arguments, context)
        except Exception as error:  # noqa: BLE001 - 工具边界必须吞异常并结构化
            logger.exception("mcp tool failed: %s", name)
            return envelope.fail(envelope.INTERNAL_ERROR, "工具执行失败：%s" % (error,),
                                 details={"tool": name})
