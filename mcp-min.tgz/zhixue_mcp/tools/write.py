# -*- coding: utf-8 -*-
"""写操作工具：存计划、更新掌握度、请求重排、按资料出题。

写操作的三条硬约束（缺一条就会在演示里出事）
--------------------------------------------
1. **幂等**：必须带 `idempotencyKey`。模型重试、网关重连都很常见，重复落库会让
   计划版本凭空 +2。
2. **乐观锁**：必须带 `expectedVersion`，与当前版本不一致返回 `CONFLICT`，
   由规划 Agent 重新读一遍再提交——不允许"后写覆盖"。
3. **身份来自 sessionRef**：`userId` 只能由服务端换出来，模型传给什么都会被拒。
"""

from __future__ import annotations

from datetime import datetime, timezone

from .. import envelope
from ..auth import idempotency_get, idempotency_put, require_actor
from ..business import modules

SESSION_REF = {"type": "string", "description": "网关签发的一次性会话引用，用于换取真实 userId"}


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _recent_plan(repository, user_id: str):
    plans = [item for item in repository.list("plans")
             if isinstance(item, dict) and item.get("userId") == user_id]
    if not plans:
        return None
    return max(plans, key=lambda item: int(item.get("version") or 0))


def _store_plan(ctx, user_id: str, plan: dict, old: dict | None, reason: str,
                evidence_ids: list) -> dict:
    """落库计划 + 版本历史。两个集合必须一起写，否则差异页会指向不存在的版本。

    `old` 必须由调用方在**写入前**取好：写完之后再查"最近版本"拿到的是新计划，
    差异会恒为空——这个 bug 只在"保存后立刻看差异"时才暴露，很难从报错里看出来。
    """
    ctx.repository.save("plans", plan["planId"], plan)
    base = old if isinstance(old, dict) and old.get("planId") == plan["planId"] else {
        "planId": plan["planId"], "version": 0, "tasks": []}
    history = modules().plans.create_plan_history(
        base, plan, reason or "mcp_save_plan", list(evidence_ids or []))
    ctx.repository.save("plan_histories", "%s:v%s" % (plan["planId"], plan.get("version")),
                        history)
    return history


def save_learning_plan(arguments: dict, ctx) -> dict:
    actor, error = require_actor(ctx.repository, arguments)
    if error:
        return error
    user_id = actor["userId"]

    plan_in = arguments.get("plan")
    if not isinstance(plan_in, dict):
        return envelope.fail(envelope.VALIDATION_ERROR, "plan 必须是计划对象")
    expected = arguments.get("expectedVersion")
    if isinstance(expected, bool) or not isinstance(expected, int):
        return envelope.fail(envelope.VALIDATION_ERROR,
                             "expectedVersion 必须是整数（首次保存传 0）")
    key = str(arguments.get("idempotencyKey") or "").strip()
    if not key:
        return envelope.fail(envelope.VALIDATION_ERROR, "缺少 idempotencyKey")

    cached = idempotency_get(ctx.repository, user_id, key)
    if isinstance(cached, dict) and isinstance(cached.get("response"), dict):
        # 重复提交：返回首次结果，并显式标记，便于前端与评测识别"这是重放"。
        replay = dict(cached["response"])
        replay["details"] = {"replayed": True, "idempotencyKey": key}
        return replay

    current = _recent_plan(ctx.repository, user_id)
    current_version = int((current or {}).get("version") or 0)
    if expected != current_version:
        return envelope.fail(
            envelope.CONFLICT, "计划版本已变化，请重新读取后再提交",
            details={"expectedVersion": expected, "currentVersion": current_version})

    plan_id = str(plan_in.get("planId") or (current or {}).get("planId") or "").strip()
    if not plan_id:
        plan_id = "plan-" + key[:16]

    new_plan = dict(plan_in)
    new_plan.update({
        "planId": plan_id,
        "version": current_version + 1,
        "userId": user_id,
        "generatedAt": plan_in.get("generatedAt") or _now(),
    })

    history = _store_plan(ctx, user_id, new_plan, current,
                          str(arguments.get("reason") or ""),
                          arguments.get("evidenceIds") or [])
    diff = modules().plans.build_plan_diff(current or {"tasks": [], "version": 0}, new_plan)

    response = envelope.ok({
        "planId": plan_id,
        "version": new_plan["version"],
        "plan": new_plan,
        "planDiff": diff,
        "history": history,
    }, trace_id=envelope.new_trace_id())
    idempotency_put(ctx.repository, user_id, key, response)
    return response


def update_mastery(arguments: dict, ctx) -> dict:
    actor, error = require_actor(ctx.repository, arguments)
    if error:
        return error
    user_id = actor["userId"]

    updates = arguments.get("updates")
    if not isinstance(updates, list) or not updates:
        return envelope.fail(envelope.VALIDATION_ERROR, "updates 不能为空数组")

    profile = ctx.repository.get("profiles", user_id)
    if not isinstance(profile, dict):
        profile = {"userId": user_id, "mastery": [], "profileVersion": 0}
    rows = [row for row in (profile.get("mastery") or []) if isinstance(row, dict)]
    index = {row.get("knowledgePointId"): row for row in rows}

    changed = []
    for item in updates:
        if not isinstance(item, dict):
            continue
        point_id = str(item.get("knowledgePointId") or "").strip()
        if not point_id:
            return envelope.fail(envelope.VALIDATION_ERROR,
                                 "updates 每项都必须含 knowledgePointId")
        try:
            score = float(item.get("assessmentScore"))
        except (TypeError, ValueError):
            return envelope.fail(envelope.VALIDATION_ERROR,
                                 "assessmentScore 必须是 0~100 的数字")
        old = float((index.get(point_id) or {}).get("masteryScore") or 0)
        try:
            new_score = modules().assessment.update_mastery(old, score)
        except ValueError as invalid:
            return envelope.fail(envelope.VALIDATION_ERROR, str(invalid),
                                 details={"knowledgePointId": point_id})

        row = index.get(point_id)
        if row is None:
            row = {"knowledgePointId": point_id, "masteryScore": new_score,
                   "source": "assessment"}
            rows.append(row)
            index[point_id] = row
        else:
            row["masteryScore"] = new_score
            row["source"] = "assessment"
        changed.append({"knowledgePointId": point_id, "oldScore": old, "newScore": new_score,
                        "assessmentScore": score})

    profile = dict(profile)
    profile["mastery"] = rows
    profile["userId"] = user_id
    profile["profileVersion"] = int(profile.get("profileVersion") or 0) + 1
    profile["updatedAt"] = _now()
    ctx.repository.save("profiles", user_id, profile)

    return envelope.ok({"mastery": changed, "profileVersion": profile["profileVersion"]},
                       trace_id=envelope.new_trace_id())


def request_replan(arguments: dict, ctx) -> dict:
    actor, error = require_actor(ctx.repository, arguments)
    if error:
        return error
    user_id = actor["userId"]

    assessment = arguments.get("assessment")
    if not isinstance(assessment, dict):
        return envelope.fail(envelope.VALIDATION_ERROR, "assessment 必须是评估结果对象")

    current = _recent_plan(ctx.repository, user_id)
    if current is None:
        return envelope.fail(envelope.NOT_FOUND, "当前没有可重排的计划",
                             details={"userId": user_id})

    state = {
        "masteryScore": assessment.get("masteryScore"),
        "incompleteTasks": int(assessment.get("incompleteTasks") or 0),
        "repeatedError": bool(assessment.get("repeatedError")),
        "assessmentScore": assessment.get("assessmentScore"),
        "knowledgePointId": assessment.get("knowledgePointId"),
    }
    decision = modules().plans.should_replan(state)
    if not decision.get("needReplan"):
        return envelope.ok({"needReplan": False, "reasons": decision.get("reasons") or [],
                            "changed": False})

    result = modules().plans.replan_learning_path(current, state)
    new_plan = result.get("plan") or current
    changed_tasks = result.get("changedTasks") or []

    if changed_tasks:
        history = _store_plan(ctx, user_id, new_plan, current, "mcp_replan", [])

        diff = modules().plans.build_plan_diff(current, new_plan)
        return envelope.ok({
            "needReplan": True,
            "changed": True,
            "reasons": decision.get("reasons") or [],
            "plan": new_plan,
            "planDiff": diff,
            "changedTasks": changed_tasks,
            "history": history,
        }, trace_id=envelope.new_trace_id())

    # 需要重排、但本轮没有可改的任务（例如练的知识点不在当前计划里）。
    # 如实返回"未改动"，不要为了看起来有产出而凭空造任务。
    return envelope.ok({"needReplan": True, "changed": False,
                        "reasons": decision.get("reasons") or [],
                        "note": "该知识点不在当前计划中，已保留原计划"}) 


def create_grounded_exercise(arguments: dict, ctx) -> dict:
    actor, error = require_actor(ctx.repository, arguments)
    if error:
        return error
    user_id = actor["userId"]

    point = str(arguments.get("knowledgePointId") or "").strip()
    if not point:
        return envelope.fail(envelope.VALIDATION_ERROR, "缺少 knowledgePointId")
    try:
        count = max(1, min(int(arguments.get("count") or 3), 5))
    except (TypeError, ValueError):
        count = 3
    kb_id = str(arguments.get("kbId") or "").strip()

    from ..business import grounded_exercises

    try:
        module = grounded_exercises()
    except Exception as unavailable:  # noqa: BLE001 - 依赖缺失要说清，不要 500
        return envelope.fail(envelope.TOOL_UNAVAILABLE,
                             "出题能力不可用（需要完整后端依赖）：%s" % (unavailable,))

    sources, source_error = module.retrieve(ctx.repository, user_id, point, kb_id)
    if source_error or not sources:
        # 没有资料就不出题——这是"有据可依"的底线，宁可让诊断去补资料。
        return envelope.fail(envelope.INSUFFICIENT_MATERIALS,
                             "该知识点没有可用资料，拒绝无依据出题",
                             details={"knowledgePointId": point, "reason": source_error or ""})

    exercises = module.generate(point, count, sources)
    if not exercises:
        return envelope.fail(envelope.INSUFFICIENT_MATERIALS,
                             "资料不足以生成可用题目", details={"knowledgePointId": point})

    public = []
    for item in exercises:
        if isinstance(item, dict):
            public.append({key: item.get(key) for key in
                           ("exerciseId", "stem", "options", "difficulty", "knowledgePointId",
                            "knowledgePointName", "source") if key in item})
    return envelope.ok({"knowledgePointId": point, "exercises": public,
                        "sources": module.public_sources(sources)
                        if hasattr(module, "public_sources") else []},
                       trace_id=envelope.new_trace_id())
